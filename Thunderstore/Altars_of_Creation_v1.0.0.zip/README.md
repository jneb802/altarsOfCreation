# All In One -  Manager Template.

Please see the individual templates for more information on how to use each one. This template is only to set up the project for you. All code provided in this template is example code and might not be needed for your specific use case.


## Template Links
- [ItemManager Mod Template](https://github.com/AzumattDev/ItemManagerModTemplate)
- [CreatureManager Mod Template](https://github.com/AzumattDev/CreatureManagerModTemplate)
- [SkillManager Mod Template](https://github.com/AzumattDev/SkillManagerModTemplate)
- [PieceManager Mod Template](https://github.com/AzumattDev/PieceManagerModTemplate)
- [LocationManager Mod Template](https://github.com/AzumattDev/LocationManagerModTemplate)
- [StatusEffectManager Mod Template](https://github.com/AzumattDev/StatusEffectManagerModTemplate)

## Original Repos from Blaxxun
- [ItemManager](https://github.com/blaxxun-boop/ItemManager)
- [CreatureManager](https://github.com/blaxxun-boop/CreatureManager)
- [SkillManager](https://github.com/blaxxun-boop/SkillManager)
- [LocationManager](https://github.com/blaxxun-boop/LocationManager)

## Original Repos from Me
- [PieceManager](https://github.com/AzumattDev/PieceManager)
- [StatusEffectManager](https://github.com/AzumattDev/StatusEffectManager)